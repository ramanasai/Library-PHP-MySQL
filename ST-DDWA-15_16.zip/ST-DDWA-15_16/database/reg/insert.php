<?php
$servername="localhost";
$username="root";
$password="";
$database="college";

$srn=$_POST['srn'];
$name =$_POST['name'];
$course =$_POST['course'];
$mobile =$_POST['mobile'];
$email=$_POST['email'];

//connection string
//$conn=new mysqli($servername,$username,$password);
$conn=new mysqli($servername,$username,$password,$database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully by OO method</br>";
/*
// Create database
$sql = "CREATE DATABASE college";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

*/
/*
// sql to create table
$sql = "CREATE TABLE student(
srn varchar(12) PRIMARY KEY,
name VARCHAR(30) NOT NULL,
course VARCHAR(30) NOT NULL,
mobile INT(10) NOT NULL,
email VARCHAR(50))";

if ($conn->query($sql) === TRUE) {
    echo "Table student created successfully";
    } else {
    echo "Error creating table: " . $conn->error;
  }

*/
//insert one record
//if(isset($_POST["insertrecord"]))
if($_POST['Insert'] == "Insert") 
{
       $sql="INSERT INTO student VALUES('$srn','$name','$course','$mobile','$email')";
       if ($conn->query($sql) === TRUE) {
          echo "New record created successfully. <br/><br/>";
        } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
  }
}


//disply inserted result
$sql = "SELECT srn, name, course, mobile, email FROM student";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<h3>SRN: " . $row["srn"]. 
      "<br/>  Name: " . $row["name"].  
      "<br/> Course:". $row["course"]. 
      "<br/> Mobile: " . $row["mobile"]. 
      "<br/>Email: " . $row["email"]. "</h3><br/>";
        }
      }
      else {
        echo "0 results". $conn->error;
       }

$conn->close();
echo "<a href=\"student.html\"> BACK </a>";
?>