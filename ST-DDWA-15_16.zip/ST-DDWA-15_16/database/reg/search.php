<?php
$servername="localhost";
$username="root";
$password="";
$database="college";

$conn=new mysqli($servername,$username,$password,$database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully by OO method</br>";

if($_POST['Search'] == "Search") 
{
      $name  = $_POST['name'];
      $sql = "SELECT * from student where name ='$name'";
      //disply inserted result
      $result = $conn->query($sql);
      print "<table border size=1>
	           <tr>
		         <th>SRN</th>
		         <th>Student Name</th> 
      		   <th>Course</th>
		         <th>Mobile</th>
		         <th>Email</th>
	           </tr>";
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_object()) {
        //echo "First Name". $firstname->firstname;
	        $srn    = $row->srn;
          $name  = $row->name;
          $course  = $row->course;
          $mobile  = $row->mobile;
          $email = $row->email;
  
  echo "<tr>
        <td>$srn</td>
		    <td>$name</td>
		    <td>$course</td> 
        <td>$mobile</td>	
		    <td>$email</td>
	     </tr>";
       }
  echo "</table>";
 }
}

$conn->close();
echo "<a href=\"student.html\"> GoBack</a>";
header('Refresh: 10; URL = student.html');
?>



