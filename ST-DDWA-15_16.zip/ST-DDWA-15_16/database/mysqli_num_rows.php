<?php
   $connection_mysql = mysqli_connect("localhost","user","password","db");
   
   if (mysqli_connect_errno($connection_mysql)){
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }
   $sql = "SELECT Lastname FROM Persons";
   //Object oriented style: int $mysqli_stmt->num_rows;
   if ($result = mysqli_query($connection_mysql,$sql)){
      $rowcount = mysqli_num_rows($result);
      
      printf("Result set has %d rows.\n",$rowcount);
      mysqli_free_result($result);
   }
   mysqli_close($connection_mysql);
   //It is a result set identifier returned by mysqli_query(), mysqli_store_result() or mysqli_use_result()
?>
DownloadsDocumentationGet InvolvedHelp
Search
mysqli_stmt::$param_count » « mysqli_stmt::next_result
PHP Manual Function Reference Database Extensions Vendor Specific Database Extensions MySQL MySQLi mysqli_stmt
Change language:  
Edit Report a Bug
mysqli_stmt::$num_rows
mysqli_stmt::num_rows
mysqli_stmt_num_rows
(PHP 5, PHP 7)

mysqli_stmt::$num_rows -- mysqli_stmt::num_rows -- mysqli_stmt_num_rows — Return the number of rows in statements result set

Description ¶
Object oriented style

int $mysqli_stmt->num_rows;
mysqli_stmt::num_rows ( void ) : int
Procedural style

mysqli_stmt_num_rows ( mysqli_stmt $stmt ) : int
Returns the number of rows in the result set. The use of mysqli_stmt_num_rows() depends on whether or not you used mysqli_stmt_store_result() to buffer the entire result set in the statement handle.

If you use mysqli_stmt_store_result(), mysqli_stmt_num_rows() may be called immediately.

Parameters ¶
stmt
Procedural style only: A statement identifier returned by mysqli_stmt_init().

Return Values ¶
An integer representing the number of rows in result set.

Examples ¶
Example #1 Object oriented style

<?php
/* Open a connection */
$mysqli = new mysqli("localhost", "my_user", "my_password", "world");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

$query = "SELECT Name, CountryCode FROM City ORDER BY Name LIMIT 20";
if ($stmt = $mysqli->prepare($query)) {

    /* execute query */
    $stmt->execute();

    /* store result */
    $stmt->store_result();

    printf("Number of rows: %d.\n", $stmt->num_rows);

    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();
?>