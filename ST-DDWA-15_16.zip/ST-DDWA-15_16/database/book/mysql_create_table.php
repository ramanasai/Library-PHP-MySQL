 <?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "book";

// Create connection with OO Method
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
/*
// sql to create  book table
$sql= "CREATE TABLE book
(book_id INTEGER PRIMARY KEY,
title varchar(20),
author_name varchar (20),
pub_year DATE)";


if ($conn->query($sql) === TRUE) {
    echo "Table Book created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// sql to create  publisher table
$sql= "CREATE TABLE book_publisher 
       (book_id int,
       publisher_name varchar(20),
  FOREIGN KEY(book_id) REFERENCES book (book_id)
  ON DELETE CASCADE
  ON UPDATE CASCADE)";


if ($conn->query($sql) === TRUE) {
    echo "<br/>Table Publisher created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
*/

// sql to create  book-lending
$sql= "CREATE TABLE book_lending
       (book_id int,card_no int,
       date_out DATE,
       date_due DATE,
  FOREIGN KEY(book_id) REFERENCES book (book_id)
  ON DELETE CASCADE
  ON UPDATE CASCADE)";


if ($conn->query($sql) === TRUE) {
    echo "<br/>Table Book-Lending created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
$conn->close();

?> 

